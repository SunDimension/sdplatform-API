<?php

namespace App\Http\Controllers;

use App\Http\Requests\RoleStoreRequest;
use App\Http\Requests\RoleUpdateRequest;
use App\Http\Resources\RoleCollection;
use App\Http\Resources\RoleResource;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class RolesController extends Controller
{
    public function index(Request $request): RoleCollection
    {
        // $roles = Role::all();

        return new RoleCollection(Role::with(['permissions'])->get());
    }

    public function store(RoleStoreRequest $request): RoleResource
    {
        $role = Role::create($request->validated());
        // $role->permissions()->sync($request->input('permissions', []));

        return new RoleResource($role);
        
    }

    public function show(Request $request, Role $role): RoleResource
    {
        return new RoleResource($role->load(['permissions']));
    }

    public function update(RoleUpdateRequest $request, Role $role): RoleResource
    {
        $role->update($request->validated());
        $role->permissions()->sync($request->input('permissions', []));

        return new RoleResource($role);
    }

   public function destroy($id): Response
    {   
       
        Role::destroy($id);

        
        return response(null, Response::HTTP_NO_CONTENT);
    }
}
